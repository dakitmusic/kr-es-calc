# 偶像夢幻祭活動計算機
- 日服Basic演出成功率計算機
- 日服Basic耗鑽計算機
- [日服Music耗鑽計算機](https://s-asakoto.github.io/es-calc/music.html)
- 海外服耗鑽計算機

# Ensemble Stars Event Calculators
- Japanese Basic Live Success Rate Calculator
- Japanese Basic Diamond Usage Calculator
- [Japanese Music Diamond Usage Calculator](https://s-asakoto.github.io/es-calc/music.html?lang=en)
- Overseas Diamond Usage Calculator

# あんスタイベント計算器
- 日本鯖Basicライブ成功率計算器
- 日本鯖Basicダイヤ消耗計算器
- [日本鯖Musicダイヤ消耗計算器](https://s-asakoto.github.io/es-calc/music.html?lang=ja)
- 海外鯖ダイヤ消耗計算器
